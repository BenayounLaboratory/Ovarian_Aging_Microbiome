setwd('/Users/minhookim/Dropbox/Benayoun_lab/Projects/Menopause_microbiome_project/Data/For_Github/Ovarian_mRNAseq/FMT_cohort/GSEA/GSEA_DBs/')
options(stringsAsFactors = FALSE)

# load libraries for analysis
library(DESeq2)
library(phenoTest)
library(qusage)   
library(readr)

###############################################
# Menopause-Microbiome project
# Process GSEA DBs
###############################################

##### Functions #####

## Process GMT files for use with ClusterProfiler
firstup <- function(x) {
  substr(x, 1, 1) <- toupper(substr(x, 1, 1))
  x
}

convert_to_mouse <- function (my.geneset.list) {
  for (i in 1:length(my.geneset.list)) {
    my.geneset.list[[i]] <- firstup(tolower( my.geneset.list[[i]]  )) 
  }
  
  return(my.geneset.list)
}

################################################################################

##### Prep and load gene sets #####
# https://data.broadinstitute.org/gsea-msigdb/msigdb/release/7.5/
# https://maayanlab.cloud/Harmonizome/dataset/
# https://maayanlab.cloud/chea3/#top
# https://www.targetscan.org/

## Load DBs
Sym.mh.all             <- read.gmt("./mh.all.v2023.1.Mm.symbols.gmt")
Sym.m2.cp.biocarta     <- read.gmt("./m2.cp.biocarta.v2023.1.Mm.symbols.gmt")
Sym.m2.cp.reactome     <- read.gmt("./m2.cp.reactome.v2023.1.Mm.symbols.gmt")
Sym.m2.cp.wiki         <- read.gmt("./m2.cp.wikipathways.v2023.1.Mm.symbols.gmt")
Sym.m3.gtrd            <- read.gmt("./m3.gtrd.v2023.1.Mm.symbols.gmt")
Sym.m5.go              <- read.gmt("./m5.go.v2023.1.Mm.symbols.gmt")
Sym.ENS.GO.ALL         <- read.gmt("./2022-12-21_mouse_Ens108_GO_ALL.gmt")
Sym.ENS.GO.BP          <- read.gmt("./2022-12-21_mouse_Ens108_GO_BP.gmt")
Sym.ENS.GO.MF          <- read.gmt("./2022-12-21_mouse_Ens108_GO_MF.gmt")
Sym.ENS.GO.CC          <- read.gmt("./2022-12-21_mouse_Ens108_GO_CC.gmt")
Sym.SEN.MAYO           <- read.gmt("./SAUL_SEN_MAYO.v2023.2.Mm.gmt")

Sym.TF.target.summary <- convert_to_mouse(read.gmt("./2020-05-20_TF_targets_ChEA_ENCODE_GEO_JASPAR_summary.gmt"))

save(Sym.mh.all,
     Sym.m2.cp.biocarta,
     Sym.m2.cp.reactome,
     Sym.m2.cp.wiki,
     Sym.m3.gtrd,
     Sym.m5.go,
     Sym.ENS.GO.ALL,
     Sym.ENS.GO.BP,
     Sym.ENS.GO.MF,
     Sym.ENS.GO.CC,
     Sym.SEN.MAYO,
     Sym.TF.target.summary,
     file = paste0(Sys.Date(),"_GeneSetCollections_for_Phenotest_GSEA_mouse.RData"))

################################################################################
sink(file = paste(Sys.Date(), "MM_FMT_Process_GeneSetCollection_for_Phenotest_GSEA_session_Info.txt", sep ="_"))
sessionInfo()
sink()
