setwd('/Users/minhookim/Dropbox/Benayoun_lab/Projects/Menopause_microbiome_project/Data/For_Github/Ovarian_mRNAseq/FMT_cohort/GSEA/')
options(stringsAsFactors = FALSE)

# load libraries for analysis
library(DESeq2)
library(phenoTest)
library(qusage)
library(ggplot2) 
library(scales) 
theme_set(theme_bw())

###############################################
# GSEA functions: run_enrich (may adjust minGenes and maxGenes)
#                 plot_bubble_plots
###############################################

# Define the start, middle, and end colors of the gradient
colors <- c("#9C509F", "white", "#F99E26")

# Create a color ramp function
colorRampFn <- colorRampPalette(colors)

# Generate a vector of, for example, 9 colors from this gradient
my.color.vector <- colorRampFn(9)

run_enrich <- function(my.matrix, data.name, my.fdr = 0.05, my.ontology, my.ontology.name) {
  
  # set seed to stabilize output (add 2020/5/20)
  set.seed(123456789)
  
  # run phenotest GSEA
  gsea.data <- gsea( x         =  my.matrix   , 
                     gsets     =  my.ontology , 
                     mc.cores  =  2           , 
                     logScale  =  FALSE       , 
                     B         =  10000       , 
                     minGenes  =  5           , 
                     maxGenes  =  5000        )
  
  my.summary <- data.frame(gsea.data$significance$summary)
  my.sig.path.num <- sum(my.summary$fdr < my.fdr )
  
  # write results to file
  my.outfile <- paste(Sys.Date(),data.name, my.ontology.name, "FDR", 100*my.fdr, "Phenotest_GSEA_Analysis_table", my.sig.path.num,"significant.txt", sep = "_")
  write.table(my.summary[my.summary$fdr < my.fdr,], file = my.outfile, quote = F, sep = "\t")
  
  return(my.summary)
}

plot_bubble_plot <- function(my.geneset.name, my.gsea.file, max.path.plot = 20){
  
  my.gsea <- read.csv(my.gsea.file, sep = "\t", header = T)
  
  my.gsea.pos <- my.gsea[my.gsea$nes > 0,]
  my.gsea.neg <- my.gsea[my.gsea$nes < 0,]
  
  my.pos.sort <- sort(my.gsea.pos$nes, index.return = T, decreasing = T) # largest value is top (positive)
  my.neg.sort <- sort(my.gsea.neg$nes, index.return = T, decreasing = F) # largest value is top (negative)
  
  if ( nrow(my.gsea.pos) == 0 || nrow(my.gsea.neg) == 0) {
    
    # if either pos or neg is empty
    if ( nrow(my.gsea.neg) == 0) {
      
      my.gsea.2 <- my.gsea.pos[my.pos.sort$ix[1:round(max.path.plot/2)],]
      
    } else {
      
      my.gsea.2 <- my.gsea.neg[my.neg.sort$ix[1:round(max.path.plot/2)],]
      
    }
    
  } else if ( (nrow(my.gsea.pos) > round(max.path.plot/2)) && (nrow(my.gsea.neg) > round(max.path.plot/2)) ) {
    
    # if enough on both sides
    my.gsea.2 <- rbind(my.gsea.pos[my.pos.sort$ix[1:round(max.path.plot/2)],],
                       my.gsea.neg[my.neg.sort$ix[1:round(max.path.plot/2)],])
    
  } else {
    
    # if not enough on both sides
    my.gsea.2 <- rbind(my.gsea.pos[my.pos.sort$ix[1:(min(round(max.path.plot/2),nrow(my.gsea.pos)))],],
                       my.gsea.neg[my.neg.sort$ix[1:(min(round(max.path.plot/2),nrow(my.gsea.neg)))],])
    
  }
  
  # create -log10 FDR for plotting
  my.gsea.2$minlog10fdr  <- -log10(my.gsea.2$fdr + 1e-30)
  my.gsea.2$Description  <- rownames(my.gsea.2)
  
  my.sorting <- sort(my.gsea.2$minlog10fdr, index.return = T, decreasing = T)
  my.gsea.sorted <- my.gsea.2[my.sorting$ix,]
  
  # create and preserve wanted display order
  my.gsea.sorted$FMT <- ifelse(my.gsea.sorted$nes > 0, "FMT_OF", "FMT_YF")
  my.gsea.sorted <- my.gsea.sorted[order(my.gsea.sorted$FMT), ]
  
  my.max.char <- max(nchar(my.gsea.sorted$Description))
  
  my.gsea.sorted$Description <- factor(my.gsea.sorted$Description, levels = rev(unique(my.gsea.sorted$Description)))
  my.gsea.sorted$CellType <- factor(rep("Ovary",length(  my.gsea.sorted$Description)))
  
  # FMT-YF/FMT-OF color scale
  my.max <- max(my.gsea.sorted$nes)
  my.min <- min(my.gsea.sorted$nes)
  
  if ( abs(my.max) > abs(my.min)) {
    my.value <- abs(my.max)
  } else {
    my.value <- abs(my.min)
  }
  
  my.values <- c(-my.value,0.75*-my.value,0.5*-my.value,0.25*-my.value,0,0.25*my.value,0.5*my.value,0.75*my.value,my.value)
  my.scaled <- rescale(my.values, to = c(0, 1))
  my.color.vector <- my.color.vector
  
  my.plot <- ggplot(my.gsea.sorted,aes(x=CellType,y=Description,colour=nes,size=minlog10fdr))+ theme_bw()+ geom_point(shape = 16)
  my.plot <- my.plot + ggtitle("gsea Analysis") + labs(x = "-log10(pvalue)", y = "")
  my.plot <- my.plot + scale_colour_gradientn(colours = my.color.vector, na.value = "grey50", guide = "colourbar", values = my.scaled)
  my.plot
  
  my.pdfname <- paste(Sys.Date(),"GSEA_MM_FMT_BALLOON_plot",my.geneset.name,"top", nrow(my.gsea.sorted),"significant_pathways.pdf", sep="_")
  
  pdf(my.pdfname, onefile=T, height = 6, width=max(4,my.max.char/8) )
  print(my.plot)
  dev.off()
  
}
